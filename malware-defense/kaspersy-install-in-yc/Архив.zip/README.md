# Развертывание Kaspersky Antivirus в Yandex.Cloud (Compute Instance, COI, k8s)
Цель демо: Развернуть решение Kaspersky и удаленно установить агенты защиты в Yandex.Cloud для обеспечения антивирусной защиты:
- виртуальных машин win, lin 
- контейнеров в [COI](https://cloud.yandex.ru/docs/cos/concepts/)(Container Optimised Image) 
- контейнеров в [Managed Kubernetes](https://cloud.yandex.ru/docs/managed-kubernetes/)

## Оглавление:
- Схема
- Описание
- Подготовка/Пререквизиты
- Развертывание инфраструктуры
- Настройка KSC
- Установка антивируса на машины:
-    -- Удаленная установка на Linux машины (включая COI)
-    -- Удаленная установка на Windows машины 
-    -- Проверка работоспособности антивируса на ВМ
-    -- Проверка работоспособности антивируса в контейнерах COI
- Удаленная установка на k8s nodes
-   --Проверка работоспособности антивируса в k8s nodes


## Схема:
![Kaspersky](https://user-images.githubusercontent.com/85429798/126876607-b05967ee-5f22-4ad0-b128-fa25704d0821.png)



## Описание:
В рамках workshop будут выполнены:
- установка инфраструктуры с помощью terraform (infrastructure as a code)
- инсталяция, базовая конфигурация и ряд тестов [Kaspersky Security для виртуальных и облачных сред (PAYG)](https://cloud.yandex.ru/marketplace/products/f2eghdh3f8nnbu389nsh) 

Установка инфраструктуры с помощью terraform:
- создание ВМ lin, win, coi
- создание ВМ Kaspersky Security Center
- создание SSH (rsa) сертификата для подключения к lin машинам

## Подготовка/Пререквизиты:
- установить и настроить [yc client](https://cloud.yandex.ru/docs/cli/quickstart)
- установить [terraform](https://www.terraform.io/downloads.html)
- установить доп. ПО: [kubectl](https://kubernetes.io/ru/docs/tasks/tools/install-kubectl/), [rdp client](https://apps.apple.com/ru/app/microsoft-remote-desktop/id1295203466?mt=12), [helm](https://helm.sh/docs/intro/install/)

Системные требования для целевых ВМ:
В рамках workshop используется Kaspersky Endpoint Security 11.2.0 для Linux - [системные требования к ОС](https://support.kaspersky.com/KES4Linux/11.2.0/en-US/219384.htm)


## Развертывание инфраструктуры:
- скачать архив с файлами ["kaspersy-install-in-yc.zip"](https://github.com/yandex-cloud/yc-solution-library-for-security/blob/master/malware-defense/kaspersy-install-in-yc/kaspersy-install-in-yc.zip)
- перейти в папку со скаченными файлами
- вставьте необходимые параметры в файле variables.tf (token, cloud_id, folder_id)(подсказки в файле)
- выполнить команды:
```
terraform init
terraform apply 
```

[<img width="1260" alt="image" src="https://user-images.githubusercontent.com/85429798/126878077-daab8d08-d898-43e3-adef-25dec7976695.png">](https://youtu.be/YLQZQhL9_-0)

Инфраструктуры подготовлена:
<img width="1363" alt="image" src="https://user-images.githubusercontent.com/85429798/126878997-a5e76fd1-c60e-41a2-b0d7-b415fa298a23.png">


## Настройка KSC:
1) Подождите 3 мин
2) Подключитесь к KSC по rdp на внешний адрес. Узнать IP можно:

```
yc compute instance list --format=json | jq '.[] | select( .name == "ksc")| .network_interfaces[0].primary_v4_address.one_to_one_nat.address '| sed 's/"//g'
```

```
логин: Administrator
пароль: !QAZ2wsx
```
- ожидаем пока KSC выполнит самонастройку (в это время выполняем шаги 3-5)

3) Terraform прокинул ssh ключ по адресу - C:\private.pem
Уберите лишние права у файла - оставить только группе administrators (правой кнопкой по файлу - security ->advanced->disable inheritance)

4) Добавим ssh ключу парольную фразу в cmd:

```
ssh-keygen -p -f C:\private.pem 
```
(указать парольную фразу)

5) Скачиваем KES 11.2 на машину KSC - архив ["updates.zip"](https://github.com/yandex-cloud/yc-solution-library-for-security/blob/master/malware-defense/kaspersy-install-in-yc/updates.zip)

6) Создаем инсталяционный пакет для KES 11.2:
- Advanced -> Remote installation -> Installation Packages -> Create ins. packet
- Выбираем create from Kasp. applications
- Указываем .kud file из C:\Users\Administrator\Desktop\kesl-11.2.0.4528 

7) Установим плагин управления запустив файл updates/klcfginst.msi

8.1) Создадим группы устройств (Managed Devices -> New Group):
- Linux
- Windows
- k8s

8.2) Создадим правила перемещения устройств в группы (Unassigned Devices -> Configure rules):
- Linux "192.168.30.0/24"
- Windows "192.168.20.0/24"
- k8s "192.168.40.0/24"

8.3) Создадим правила опроса сети по тем же подсетям. Advanced -> Device Discovery -> IP ranges (обязательно нажать правой кнопкой на IP ranges -> включить poll)

## Установка антивируса на машины
Антивирусное ПО Kaspersly состоит из 2-х частей: агент управления и антивирусное ПО (Kaspersky Endpoint Security (linux),Kaspersky Windows Security (windows))
Установка антивируса на машины возможна следующими способами:
- удаленно с помощью ssh либо windows credentials
- с помощью выполнения локального скрипта установки (подробнее в [документации](https://support.kaspersky.ru/15623#block4)) 

#### Удаленная установка на Linux мшаины (включая COI)
10) Создать задачу на авто установку антивирусного агента + KES linux
- создать задачу из папки Managed Device -> Linux (можно задать расписание)
- указать ssh credentials сертификата , выбрать пакет KES 11.2 и агент 12
- дождаться успешной установки

10.1) Создать задачи:
- загрузка обновления в хранилище KSC 
- обновление KESL баз на машинах
- задачу полной проверки

Зайти в список машин - убедиться, что антивирус установлен

#### Удаленная установка на Windows мшаины 
*В terraform скрипте уже предусмотрено отключение Windows Firewall и удаление Windows Defender

11) Создать задачу на авто установку антивирусного агента + KWS:
- создать задачу из папки Managed Device -> Windows (можно задать расписание)
- указать windows credentials , выбрать пакет 11.1 и агент 12 
- дождаться установки агента и антивируса на машины

Зайти в список машин - убедиться, что антивирус установлен


#### Проверка работоспособности антивируса на ВМ (lin и win):
12) Зайти по ssh на любую lin машину и выполнить команду:

```
sudo wget https://secure.eicar.org/eicar.com.txt
```
Скачивание заблокировано 
Убедиться в events данной машины, что угроза обнаружена

13) Зайти по rdp на любую win машину, скачать сэмп вируса eicar - https://secure.eicar.org/eicar.com.txt
- зайти в свойства любой win машины, убедиться, что антивирус удалил eicar сэмпл


#### Проверка работоспособности антивируса в контейнерах COI:
Подробнее о сканировании контейнеров - https://support.kaspersky.com/KES4Linux/11.1.0/ru-RU/191702.htm

На ВМ container-lin уже скачен и запущен уязвимый docker image - https://hub.docker.com/r/jerbi/eicar

14) Создать задачу сканирования контейнеров на ВМ container-lin. 
- зайти в Tasks
- create new task -> KESL 11.2 -> сканирование контейнеров

- убедиться, что в событиях видно обнаружение вредоносного image, контейнера

## Удаленная установка на k8s nodes
Установка антивируса на k8s nodes возможна следующими способами:
- установка через helm chart [yc-kes](https://mirtov-alexey.github.io/yc-kes/) с помощью подготовленного [daemonset](https://kubernetes.io/docs/concepts/workloads/controllers/daemonset/), который обеспечивает постоянное наличие агента на всех нодах кластера с помощью [локального скрипта развертывания](https://support.kaspersky.ru/15623#block4)) 
- автоматическая удаленная установка антивируса по расписанию на все существующие и новые ноды штатными средствами KSC по расписанию c помощью ssh сертификата и сканирования сети (по аналогии с п. 10)

Будем выполнять вариант через helm chart (как более cloud native)

15) Выполнить [добавление учетных данных в конфиг файл kubect](https://cloud.yandex.ru/docs/managed-kubernetes/quickstart#add-conf)

```
yc managed-kubernetes cluster get-credentials --id $(yc managed-kubernetes cluster list --format=json | jq '.[].id'| sed 's/"//g') --external --force
```

16) установим агента через helm

```
helm repo add yc-kes https://mirtov-alexey.github.io/yc-kes/ 

helm install yc-kes yc-kes/yc-kes --set kscServer=ksc.ru-central1.internal
*в поле kscServer необходимо указать имя ksc сервера (в рамках демо оно уже заполнено)

* можно запустить в режиме dry-run для просмотра содержимого: 
helm install yc-kes yc-kes/yc-kes --set kscServer=ksc.ru-central1.internal --dry-run --debug

kubectl get daemonsets
k get configmaps 


```

17) Создать задачу на автоматическую установку KES на k8s ноды с установленным агентом (по аналогии с linux)
- зайти
- убедиться, что KES установлен

*Важно: в новой будущей версии KSC этот шаг можно будет не выполнять

18) установить yaml manifest, который содержит jerbi/eicar и войти в него (exec)
```
k run virus-pod --image=jerbi/eicar --command -- sleep 4800

```
#### Проверка работоспособности антивируса в k8s nodes
19) скачать вирусный сэмпл в pod - убедиться, что он удалился и проверить событие в свойствах данной ВМ

```
kubectl exec virus-pod -it -- sh 

curl https://secure.eicar.org/eicar.com.txt -O virus.txt
```
20) Запустить задачу скана контейнеров 
- показать что нашелся вирус в контейнере
- показать что в events обычным антивирусом удалился файл







