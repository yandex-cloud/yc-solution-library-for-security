# Развертывание Kaspersky Antivirus в Yandex.Cloud (Compute Instance, COI)
Цель демо: Развернуть решение Kaspersky и удаленно установить агенты защиты в Yandex.Cloud для обеспечения антивирусной защиты:
- виртуальных машин win, lin 
- контейнеров в [COI](https://cloud.yandex.ru/docs/cos/concepts/)(Container Optimised Image) 

## Оглавление:
- Схема
- Описание
- Подготовка/Пререквизиты
- Развертывание инфраструктуры
- Настройка KSC
- Установка антивируса на машины:
-    -- Удаленная установка на Linux машины (включая COI)
-    -- Удаленная установка на Windows машины 
-    -- Проверка работоспособности антивируса на ВМ
-    -- Проверка работоспособности антивируса в контейнерах COI


## Схема:
![Kaspersky](https://user-images.githubusercontent.com/85429798/126876607-b05967ee-5f22-4ad0-b128-fa25704d0821.png)



## Описание:
В рамках workshop будут выполнены:
- установка инфраструктуры с помощью terraform (infrastructure as a code)
- инсталяция, базовая конфигурация и ряд тестов [Kaspersky Security для виртуальных и облачных сред (PAYG)](https://cloud.yandex.ru/marketplace/products/f2eghdh3f8nnbu389nsh) 


## Подготовка/Пререквизиты:
- установить и настроить [yc client](https://cloud.yandex.ru/docs/cli/quickstart)
- установить [terraform](https://www.terraform.io/downloads.html)
- установить доп. ПО: [kubectl](https://kubernetes.io/ru/docs/tasks/tools/install-kubectl/), [rdp client](https://apps.apple.com/ru/app/microsoft-remote-desktop/id1295203466?mt=12)

Системные требования для целевых ВМ:
В рамках workshop используется Kaspersky Endpoint Security 11.2.0 для Linux - [системные требования к ОС](https://support.kaspersky.com/KES4Linux/11.2.0/en-US/219384.htm)


## Развертывание инфраструктуры:
- скачать архив с файлами ["kaspersy-install-in-yc.zip"](https://github.com/yandex-cloud/yc-solution-library-for-security/blob/master/malware-defense/kaspersy-install-in-yc/kaspersy-install-in-yc.zip)
- перейти в папку со скаченными файлами
- вставьте необходимые параметры в файле variables.tf (token, cloud_id, folder_id)(подсказки в файле)
- выполнить команды:
```
terraform init
terraform apply 
```

[<img width="1260" alt="image" src="https://user-images.githubusercontent.com/85429798/126878077-daab8d08-d898-43e3-adef-25dec7976695.png">](https://youtu.be/YLQZQhL9_-0)

Инфраструктуры подготовлена:
<img width="1363" alt="image" src="https://user-images.githubusercontent.com/85429798/126878997-a5e76fd1-c60e-41a2-b0d7-b415fa298a23.png">


## Настройка KSC:
1) Подождите 3 мин
2) Подключитесь к KSC по rdp на внешний адрес. Узнать IP можно:

```
ip адрес будет отображен в output командной строки
```

```
логин: Administrator
пароль: !QAZ2wsx
```
- ожидаем пока KSC выполнит самонастройку (в это время выполняем шаги 3-5)

3) Terraform прокинул ssh ключ по адресу - C:\private.pem
Уберите лишние права у файла - оставить только группе administrators (правой кнопкой по файлу - security ->advanced->disable inheritance)

4) Добавим ssh ключу парольную фразу в cmd:

```
ssh-keygen -p -f C:\private.pem 
```
(указать парольную фразу)

5) Скачиваем KES 11.2 на машину KSC - архив ["updates.zip"](https://github.com/yandex-cloud/yc-solution-library-for-security/blob/master/malware-defense/kaspersy-install-in-yc/updates.zip)

6) Создаем инсталяционный пакет для KES 11.2:
- Advanced -> Remote installation -> Installation Packages -> Create ins. packet
- Выбираем create from Kasp. applications
- Указываем .kud file из C:\Users\Administrator\Desktop\kesl-11.2.0.4528 

7) Установим плагин управления запустив файл updates/klcfginst.msi

8.1) Создадим группы устройств (Managed Devices -> New Group):
- Linux
- Windows

8.2) Создадим правила перемещения устройств в группы (Unassigned Devices -> Configure rules):
- Linux "192.168.30.0/24"
- Windows "192.168.20.0/24"

8.3) Создадим правила опроса сети по тем же подсетям. Advanced -> Device Discovery -> IP ranges (обязательно нажать правой кнопкой на IP ranges -> включить poll)

[<img width="902" alt="image" src="https://user-images.githubusercontent.com/85429798/126906082-c30255b2-f714-44d9-ab25-b064a7906c88.png">](https://www.youtube.com/watch?v=dTAP5QDTlGY)


## Установка антивируса на машины
Антивирусное ПО Kaspersly состоит из 2-х частей: агент управления и антивирусное ПО (Kaspersky Endpoint Security (linux),Kaspersky Windows Security (windows))
Установка антивируса на машины возможна следующими способами:
- удаленно с помощью ssh либо windows credentials
- с помощью выполнения локального скрипта установки (подробнее в [документации](https://support.kaspersky.ru/15623#block4)) 

#### Удаленная установка на Linux мшаины (включая COI)
10) Создать задачу на авто установку антивирусного агента + KES linux
- создать задачу из папки Managed Device -> Linux (можно задать расписание)
- указать ssh credentials сертификата , выбрать пакет KES 11.2 и агент 12
- дождаться успешной установки

10.1) Создать задачи:
- загрузка обновления в хранилище KSC 
- обновление KESL баз на машинах
- задачу полной проверки

Зайти в список машин - убедиться, что антивирус установлен

#### Удаленная установка на Windows мшаины 

11.1) Зайти по rdp на ВМ win0 или win1 и выполнить следующую команду в powershell для удаления windows defender:

```
sc query WinDefend
Uninstall-WindowsFeature -Name Windows-Defender
Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False
```

11) Создать задачу на авто установку антивирусного агента + KWS:
- создать задачу из папки Managed Device -> Windows (можно задать расписание)
- указать windows credentials , выбрать пакет 11.1 и агент 12 
- дождаться установки агента и антивируса на машины

Зайти в список машин - убедиться, что антивирус установлен


#### Проверка работоспособности антивируса на ВМ (lin и win):
12) Зайти по ssh на любую lin машину и выполнить команду:

```
sudo wget https://secure.eicar.org/eicar.com.txt
```
Скачивание заблокировано 
Убедиться в events данной машины, что угроза обнаружена

13) Зайти по rdp на любую win машину, скачать сэмп вируса eicar - https://secure.eicar.org/eicar.com.txt
- зайти в свойства любой win машины, убедиться, что антивирус удалил eicar сэмпл


#### Проверка работоспособности антивируса в контейнерах COI:
Подробнее о сканировании контейнеров - https://support.kaspersky.com/KES4Linux/11.1.0/ru-RU/191702.htm

На ВМ container-lin уже скачен и запущен уязвимый docker image - https://hub.docker.com/r/jerbi/eicar

14) Создать задачу сканирования контейнеров на ВМ container-lin. 
- зайти в Tasks
- create new task -> KESL 11.2 -> сканирование контейнеров

- убедиться, что в событиях видно обнаружение вредоносного image, контейнера

[<img width="1151" alt="image" src="https://user-images.githubusercontent.com/85429798/126909589-131fa521-3362-4312-b9c1-3f49c289a0d2.png">](https://www.youtube.com/watch?v=7yHlL6ALFaM)
