##

![Kaspersky](https://user-images.githubusercontent.com/85429798/124883024-9a9fe700-dfd9-11eb-82d6-1f795b4ee383.jpg) 


Подготовка:

-установить yc client (ссылка на инструкцию по установке и настройке https://cloud.yandex.ru/docs/cli/quickstart)
-настроить авторизацию в YC для Terraform:

export YC_TOKEN=$(yc iam create-token)
export YC_CLOUD_ID=$(yc config get cloud-id)
export YC_FOLDER_ID=$(yc config get folder-id)

-установить terraform https://www.terraform.io/downloads.html
-скачать архив с файлами "kaspersy-install-in-yc.zip"


Развертывание:
-перейти в папку со скаченными файлами
-terraform init
-terraform apply 



Описание шагов workshop:

1) Подождите 3 мин
2) Подключитесь к KSC по rdp на внешний адрес
адрес - будет показан в output в командной строке
логин: Administrator
пароль: !QAZ2wsx

3)



