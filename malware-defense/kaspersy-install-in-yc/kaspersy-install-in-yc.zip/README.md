# Развертывание Kaspersky Antivirus в Yandex.Cloud (Compute Instance, COI, k8s)
Цель демо: Развернуть решение Kaspersky и удаленно установить агенты защиты в Yandex.Cloud для обеспечения антивирусной защиты:
- виртуальных машин win, lin 
- контейнеров в [COI](https://cloud.yandex.ru/docs/cos/concepts/)(Container Optimised Image) 
- контейнеров в [Managed Kubernetes](https://cloud.yandex.ru/docs/managed-kubernetes/)

## Оглавление:
- Схема
- Описание
- Подготовка/Пререквизиты
- Развертывание инфраструктуры
- Настройка KSC
- Установка антивируса на машины:
-    -- Удаленная установка на Linux мшаины (включая COI)
-    -- Удаленная установка на Windows мшаины 
-    -- Проверка работоспособности антивируса на ВМ
-    -- Проверка работоспособности антивируса в контейнерах COI
- Удаленная установка на k8s nodes
-   --Проверка работоспособности антивируса в k8s nodes


## Схема:
![Kaspersky](https://user-images.githubusercontent.com/85429798/126876607-b05967ee-5f22-4ad0-b128-fa25704d0821.png)



## Описание:
В рамках workshop будут выполнены:
- установка инфраструктуры с помощью terraform (infrastructure as a code)
- инсталяция, базовая конфигурация и ряд тестов [Kaspersky Security для виртуальных и облачных сред (PAYG)](https://cloud.yandex.ru/marketplace/products/f2eghdh3f8nnbu389nsh) 

Установка инфраструктуры с помощью terraform:
- создание ВМ lin, win, coi
- создание ВМ Kaspersky Security Center
- создание SSH (rsa) сертификата для подключения к lin машинам

## Подготовка/Пререквизиты:
- установить и настроить [yc client](https://cloud.yandex.ru/docs/cli/quickstart)
- установить [terraform](https://www.terraform.io/downloads.html)
- установить доп. ПО: [kubectl](https://kubernetes.io/ru/docs/tasks/tools/install-kubectl/), [rdp client](https://apps.apple.com/ru/app/microsoft-remote-desktop/id1295203466?mt=12), [helm](https://helm.sh/docs/intro/install/)
- вставьте необходимые параметры в файле variables.tf (token, cloud_id, folder_id)(подсказки в файле)

Системные требования для целевых ВМ:
В рамках workshop используется Kaspersky Endpoint Security 11.2.0 для Linux - [системные требования к ОС](https://support.kaspersky.com/KES4Linux/11.2.0/ru-RU/206762.htm)


## Развертывание инфраструктуры:
- скачать архив с файлами ["kaspersy-install-in-yc.zip"](указать ссылку)
- перейти в папку со скаченными файлами
- выполнить команды:
```
terraform init
terraform apply 
```

## Настройка KSC:
1) Подождите 3 мин
2) Подключитесь к KSC по rdp на внешний адрес. Узнать IP можно:

```
yc compute instance list --format=json | jq '.[] | select( .name == "ksc")| .network_interfaces[0].primary_v4_address.one_to_one_nat.address '| sed 's/"//g'
```

```
логин: Administrator
пароль: !QAZ2wsx
```
- ожидаем пока KSC выполнит самонастройку (в это время выполняем шаги 3-5)

3) Terraform прокинул ssh ключ по адресу - C:\private.pem
Уберите лишние права у файла - оставить только группе administrators (правой кнопкой по файлу - security)

4) добавить ssh ключу парольную фразу в cmd:

```
ssh-keygen -p -f C:\private.pem 
```
(указать парольную фразу)

5) скачиваем KES 11.2 на машину KSC - архив ["updates.zip"](указать ссылку)

6) Создаем инсталяционный пакет для KES 11.2:
- 

7) установить плагин управления запустив файл updates/klcfginst.msi

8) Добавляем IP диапозон необходимых ВМ в "Опрос сети":
- пап
- указываем следующие сети: "192.168.20.0/24" (win), "192.168.30.0/24 (lin)", "192.168.40.0/24 (k8s)"

9) создаем правила переноса в группу managed по папкам подсетей, в случае когда на ВМ уже установлен агент Kaspersky

## Установка антивируса на машины
Антивирусное ПО Kaspersly состоит из 2-х частей: агент управления и антивирусное ПО (Kaspersky Endpoint Security (linux),Kaspersky Windows Security (windows))
Установка антивируса на машины возможна следующими способами:
- удаленно с помощью ssh либо windows credentials
- с помощью выполнения локального скрипта установки (подробнее в [документации](https://support.kaspersky.ru/15623#block4)) 

#### Удаленная установка на Linux мшаины (включая COI)
10) Создать задачу на авто установку антивирусного агента + KES linux на папку с новыми lin машинами:
- создать задачу
- указать папку linux 
- указать ssh credentials сертификата , выбрать пакет KES 11.2 и агент 12
- можно задать расписание

#### Удаленная установка на Windows мшаины 
11) Создать задачу на авто установку антивирусного агента + KWS на папку с новыми win машинами:
- создать задачу
- указать все найденные win ПК
- указать windows credentials , выбрать пакет 11.1 и агент 12 
- можно задать расписание

Дождаться установки агента и антивируса на машины

Зайти в список машин - убедиться, что антивирус установлен

#### Проверка работоспособности антивируса на ВМ:
12) Согласно terraform на lin машины автоматически скачивается сэмпл eicar 
- зайти в свойства любой lin машины, убедиться, что антивирус удалил eicar сэмпл

13) Зайти по rdp на любую win машину, скачать сэмп вируса eicar - https://secure.eicar.org/eicar.com.txt
- зайти в свойства любой lin машины, убедиться, что антивирус удалил eicar сэмпл

#### Проверка работоспособности антивируса в контейнерах COI:
Подробнее о сканировании контейнеров - https://support.kaspersky.com/KES4Linux/11.1.0/ru-RU/191702.htm

На ВМ container-lin уже скачен и запущен уязвимый docker image - https://hub.docker.com/r/jerbi/eicar
14) Создать задачу сканирования контейнеров на ВМ container-lin. 
- зайти ..

- убедиться, что в событиях видно обнаружение вредоносного image, контейнера

## Удаленная установка на k8s nodes
Установка антивируса на k8s nodes возможна следующими способами:
- установка через helm chart [yc-kes](https://mirtov-alexey.github.io/yc-kes/) с помощью подготовленного [daemonset](https://kubernetes.io/docs/concepts/workloads/controllers/daemonset/), который обеспечивает постоянное наличие агента на всех нодах кластера с помощью [локального скрипта развертывания](https://support.kaspersky.ru/15623#block4)) 
- автоматическая удаленная установка антивируса по расписанию на все существующие и новые ноды штатными средствами KSC по расписанию c помощью ssh сертификата и сканирования сети (по аналогии с п. 10)

Будем выполнять вариант через helm chart (как более cloud native)

15) Выполнить [добавление учетных данных в конфиг файл kubect](https://cloud.yandex.ru/docs/managed-kubernetes/quickstart#add-conf)

```
yc managed-kubernetes cluster get-credentials --id $(yc managed-kubernetes cluster list --format=json | jq '.[].id'| sed 's/"//g') --external --force
```

!!пометить, что инструкция от Каспера не актуальная https://support.kaspersky.ru/15623#block4
Потому что в папочке public хранится старый kesl.необходимо заменить его на новый kesl 11.2

16) установим агента через helm

```
helm repo add yc-kes https://mirtov-alexey.github.io/yc-kes/ 

helm install yc-kes yc-kes/yc-kes --set kscServer=ksc.ru-central1.internal
*в поле kscServer необходимо указать имя ksc сервера (в рамках демо оно уже заполнено)
```

17) Создать задачу на автоматическую установку KES на k8s ноды с установленным агентом
- зайти
- убедиться, что KES установлен

18) установить yaml manifest, который содержит jerbi/eicar и войти в него (exec)
```
kubectl run virus-pod --image=jerbi/eicar

kubectl exec virus-pod -it -- sh 
```
#### Проверка работоспособности антивируса в k8s nodes
19) скачать вирусный сэмпл в pod - убедиться, что он удалился и проверить событие в свойствах данной ВМ
- curl https://secure.eicar.org/eicar.com.txt -O virus.txt

20) Запустить задачу скана контейнеров 
- показать что нашелся вирус в контейнере
- показать что в events обычным антивирусом удалился файл







